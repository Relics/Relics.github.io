#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

#define MONTH_PER_YEAR	12
#define WEEK_PER_YEAR	52
#define PERCENTAGE		0.03
#define MAX				400

// Abstract Base Class
class Employee{
protected:
	string name;
	double unit;
public:
	Employee(double x,string str);
	// virtual destructor
	virtual ~Employee(){};
	string getName(void);
	// Polymorphism
	// Pure Virtual Function
	virtual double getSum(void)=0;
};

// Inheritance
class MonthEmployee:public Employee{
public:
	// Initializer list
	MonthEmployee(double x,string str):Employee(x,str){};
	~MonthEmployee(){};
	double getSum(void);
};

// Inheritance
class WeekEmployee:public Employee{
public:
	// Initializer list
	WeekEmployee(double x,string str):Employee(x,str){};
	~WeekEmployee(){};
	double getSum(void);
};

// Inheritance
class SaleEmployee:public Employee{
public:
	// Initializer list
	SaleEmployee(double x,string str):Employee(x,str){};
	~SaleEmployee(){};
	double getSum(void);
};

int main()
{
	int n;
	cout << "How many members are there in this company?  ";
	cin >> n;
	cout << endl;

	// Employee useless; // you can never do this.
	Employee *member[MAX];
	double unit;
	string type,name;
	for (int i = 0; i < n; i++)
	{
		cout << "Enter the name for employee " << i+1 << ": ";
		cin >> name;
		cout << "What kind of employee is he/she?  ";
		cin >> type;

		if (type == "MonthEmployee")
		{
			cout << "The salary per month: $";
			cin >> unit;
			// A pointer of the base class can point to its derived object.
			member[i] = new MonthEmployee(unit,name);
		}
		else if (type == "WeekEmployee")
		{
			cout << "The salary per week: $";
			cin >> unit;
			// A pointer of the base class can point to its derived object.
			member[i] = new WeekEmployee(unit,name);
		}
		else if (type == "SaleEmployee")
		{
			cout << "The total sale: ";
			cin >> unit;
			// A pointer of the base class can point to its derived object.
			member[i] = new SaleEmployee(unit,name);
		}

		cout << endl;
	}

	int m;
	cout << "How many inquiries about salary are there?  ";
	cin >> m;
	for (int i = 0; i < m; i++)
	{
		cout << "Inquiry " << i+1 << " comes from: ";
		cin >> name;
		for (int j = 0; j < n; j++)
			if (name == member[j]->getName())
			{
				cout << "His/her salary for the whole year is $" << member[j]->getSum() << ".\n\n";		
				break;
			}
	}

	for (int i = 0; i < n; i++)
		delete member[i];

	system("pause");
	return 0;
}

Employee::Employee(double x,string str)
{
	unit = x;
	name = str; 
}

string Employee::getName(void)
{
	return name;
}

double MonthEmployee::getSum(void)
{
	return MONTH_PER_YEAR * unit;
}

double WeekEmployee::getSum(void)
{
	return WEEK_PER_YEAR * unit;
}

double SaleEmployee::getSum(void)
{
	return PERCENTAGE * unit;
}