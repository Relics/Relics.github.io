#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

class Student
{
	string name,id;
	int lab[3],assign[3],mid,final;
	double grade;
public:
	Student() {};
	~Student() {};
	void setStudent(void);
	void updateGrade(const double labW,const double assignW,const double midW,const double finalW);
	double getGrade();
	string getName();
};

class Course
{
	string name;
	int tot;
	double labW,assignW,midW,finalW;
	Student *stu;
	void sortGrade();
public:
	Course() {};
	~Course() {};
	void setCourse(void);
	void updateData(void);
	void getData(void);
};

void swap(Student &a, Student &b);

int main()
{
	Course vg101;
	vg101.setCourse();
	vg101.updateData();
	vg101.getData();
	system("pause");
	return 0;
}

void swap(Student &a, Student &b)
{
	Student t = a;
	a = b;
	b = t;
}

inline void Course::setCourse(void)
{
	cout << "The name of the course: ";
	cin >> name;
}

void Course::updateData(void)
{
	cout << "Total name of the students: ";
	cin >> tot;
	stu = new Student [tot];
	cout << "Total weight for lab: ";
	cin >> labW;
	cout << "Total weight for assignment: ";
	cin >> assignW;
	cout << "Total weight for mid-term exam: ";
	cin >> midW;
	cout << "Total weight for final-term exam: ";
	cin >> finalW;

	for (int i = 0; i < tot; i++)
	{
		cout << "Print the data for student " << i+1 << ":" << endl;
		stu[i].setStudent();
		stu[i].updateGrade(labW,assignW,midW,finalW);
	}
}

void Course::sortGrade(void)
{
	for (int i = 0; i < tot; i++)
		for (int j = i; j < tot; j ++)
			if (stu[j].getGrade() > stu[i].getGrade())
				swap(stu[i],stu[j]);
}

void Course::getData(void)
{
	sortGrade();
	cout << "The final rank for " << name << " is:" << endl;
	for (int i = 0; i < tot; i++)
		if (i < 9)
			cout << "00" << i+1 << ": " << stu[i].getName() << endl;
		else if (i < 99)
			cout << "0" << i+1 << ": " << stu[i].getName() << endl;
		else
			cout << i+1 << ": " << stu[i].getName() << endl;
}

void Student::setStudent(void)
{
	cout << "Name: ";
	cin >> name;
	cout << "ID: ";
	cin >> id;
	for (int i = 0; i < 3; i++)
	{
		cout << "Grade for lab " << i+1 << ": ";
		cin >> lab[i];
	}
	for (int i = 0; i < 3; i++)
	{
		cout << "Grade for assignment " << i+1 << ": ";
		cin >> assign[i];
	}
	cout << "Grade for mid-term exam: ";
	cin >> mid;
	cout << "Grade for final exam: ";
	cin >> final;
}

void Student::updateGrade(const double labW,const double assignW,const double midW,const double finalW)
{
	grade = labW * (lab[0] + lab[1] + lab[2]) / 3 + 
			assignW * (assign[0] + assign[1] + assign[2]) / 3 + 
			midW * mid + finalW * final;
}

double Student::getGrade()
{
	return grade;
}

string Student::getName()
{
	return name;
}