/********************************
* This code is to calculate the *
* sum of harmonic series. >_<   *
*********************************/

// Date: 2012-10-29

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define EULER 0.5772156649
#define LMT 1e6

double calcHarmoSum(int n);

int main()
{
	int n,i;
	double ans = 0;
	scanf("%d",&n);

	if (n > 0)
		ans = calcHarmoSum(n);
	else
	{
		printf("Input Error!\n");
		system("pause");
		return 0;
	}		


	printf("The sum is: %lf\n",ans);
	system("pause");
	return 0;
}

double calcHarmoSum(int n)
{
	int i;
	double ans = 0;

	if (n > LMT)
		ans = log((double) n) + EULER;
	else
		for (i = 1; i <= n; i++)
			ans += (double) 1/i;

	return ans;
}

