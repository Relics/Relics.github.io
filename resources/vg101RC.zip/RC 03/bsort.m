function  a = bsort(a)
    n = length(a);
    for i = 1:n
        for j = (i + 1):n
            if (a(i) > a(j))
                a(i)
                a(j)
                t = a(i);
                a(i) = a(j);
                a(j) = t;
                a(i)
                a(j)
            end
        end
    end
return