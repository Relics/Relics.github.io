a = randi(100,1,7)
a = bsort(a);
a